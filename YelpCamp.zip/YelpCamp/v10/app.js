var express = require('express');
var app = express();
var methodOverride = require('method-override');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var flash = require('connect-flash');
var passport = require('passport');
var localStrategy = require('passport-local');
var Campground = require('./models/campground');
var Comment = require('./models/comment');
var seedDB = require('./seeds');
var User = require('./models/user');
var commentRoutes = require('./routes/comments');
var campgroundRoutes = require('./routes/campgrounds');
var indexRoutes = require('./routes/index');


mongoose.set('useUnifiedTopology', true);
var url = process.env.DATABASEURL || "mongodb://localhost:27017/yelp_camp_v8" ; //this sets a default url if DATABASEURL doesnt work
mongoose.connect(url);
// mongoose.connect(process.env.DATABASEURL); //databaseurl represents both urls depending on where you access it from. We used export="url" in local and set it manually in heroku
//bottom two urls can be erased since we are using env.databaseurl for both urls
// mongoose.connect("mongodb://localhost:27017/yelp_camp_v8", {useNewUrlParser: true});
// mongoose.connect("mongodb+srv://Matt:soony@cluster0-yaf1d.mongodb.net/test?retryWrites=true&w=majority");
app.use(bodyParser.urlencoded({extended: true}));
app.set('view engine', 'ejs');
app.use(express.static(__dirname + "/public"));
app.use(methodOverride("_method"));
app.use(flash());
//seedDB();

//PASSPORT CONFIGURATION
app.use(require("express-session")({
	secret: "soony is cutest doge",
	resave: false,
	saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());
passport.use(new localStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use(function(req, res, next){
	res.locals.currentUser = req.user;
	res.locals.error = req.flash("error");
	res.locals.success = req.flash("success");
	next();
});

app.use(indexRoutes);
app.use(campgroundRoutes);
app.use(commentRoutes);


app.listen(process.env.PORT||3000,process.env.IP,function(){
	console.log("server is listening");
});