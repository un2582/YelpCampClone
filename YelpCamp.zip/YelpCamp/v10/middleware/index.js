var Campground = require('../models/campground');
var Comment = require('../models/comment');

var middlewareObj = {};
middlewareObj.checkCampgroundOwnership = function(req, res, next){
	if(req.isAuthenticated()){
		//if so find the campground
		Campground.findById(req.params.id, function(err, foundCampground){
			if(err){
				req.flash("error", "Campground Not Found");
				res.redirect("back");
			}else{
				//author.id is object, req.user._id is string, both same string tho, use equals method to turn both into string
				if(foundCampground.author.id.equals(req.user._id)){
					next();
				}else{
					req.flash("error", "You Don't Have Permission To Do That");
					res.redirect("back");
				}
			}
		});
	//if not logged in go to log in page
	}else{
		req.flash("error", "Please Login First");
		res.redirect("/login");
	}
};

middlewareObj.checkCommentOwnership = function(req, res, next){
	//is user logged in?
	if(req.isAuthenticated()){
		//if so find the comment
		Comment.findById(req.params.comment_id, function(err, foundComment){
			if(err){
				console.log(err);
			}else{
				//author.id is object, req.user._id is string, both same string tho, use equals method to turn both into string
				if(foundComment.author.id.equals(req.user._id)){
					next();
				}else{
					req.flash("You Don't Have Permission To Do That");
					res.redirect("back");
				}
			}
		});
	//if not logged in go to log in page
	}else{
		req.flash("error", "Please Login First");
		res.redirect("back");
	}
};

middlewareObj.isLoggedIn = function(req, res, next){
	if(req.isAuthenticated()){
		return next();
	}
	req.flash("error","Please Log in First!");
	res.redirect("/login");
};

// //could have also done this
// middlewareObj = {
// 	checkCampgroundOwnership: function(){
		
// 	}
// }

module.exports = middlewareObj;