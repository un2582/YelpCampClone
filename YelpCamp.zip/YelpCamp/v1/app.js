var express = require('express');
var app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({extended: true}));
app.set('view engine', 'ejs');

var campgrounds = [
		{name:"Salmon Creek",image:"https://images.pexels.com/photos/1687845/pexels-photo-1687845.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"},
		{name:"Mountain Mama",image:"https://images.pexels.com/photos/1687845/pexels-photo-1687845.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"},
		{name:"Ol Yeller",image:"https://images.pexels.com/photos/1687845/pexels-photo-1687845.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"}
	];

app.get('/', function(req,res){
	res.render('landing');
});

app.get('/campgrounds', function(req,res){	
	res.render('campgrounds', {campgrounds:campgrounds});
});

app.post('/campgrounds', function(req,res){
	var name = req.body.name;
	var image = req.body.image;
	var newCampgrounds = {name: name, image: image};
	campgrounds.push(newCampgrounds);
	res.redirect('/campgrounds');
});

app.get('/campgrounds/new', function(req,res){
	res.render('new');
});

app.listen(3000,function(){
	console.log("Server is listening");
});